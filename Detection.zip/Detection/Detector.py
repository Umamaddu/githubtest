import numpy as np
import cv2

def detect(frame, debugMode):
    # Convert frame from BGR to GRAY
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    if debugMode:
        cv2.imshow('gray', gray)
    
    # Edge detection using Canny function
    img_edges = cv2.Canny(gray, 50, 190, 3)
    
    if debugMode:
        cv2.imshow('img_edges', img_edges)
    
    # Convert to binary image
    _, img_thresh = cv2.threshold(img_edges, 127, 255, cv2.THRESH_BINARY)
    
    if debugMode:
        cv2.imshow('img_thresh', img_thresh)
    
    # Find contours
    contours, _ = cv2.findContours(img_thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    # Set the accepted minimum and maximum radius of a detected object
    min_radius_thresh = 3
    max_radius_thresh = 30   
    centers = []
    
    for c in contours:
        # Compute enclosing circle for contour
        (x, y), radius = cv2.minEnclosingCircle(c)
        radius = int(radius)
        
        # Take only the valid circles
        if radius > min_radius_thresh and radius < max_radius_thresh:
            centers.append(np.array([[x], [y]]))
    
    cv2.imshow('contours', img_thresh)
    return centers

def main():
    # Create OpenCV video capture object
    VideoCap = cv2.VideoCapture('video/randomball.avi')
    # Variable used to control the speed of reading the video
    ControlSpeedVar = 100  # Lowest: 1 - Highest:100
    HiSpeed = 100
    debugMode = True
    
    while True:
        # Read frame
        ret, frame = VideoCap.read()
        
        # If frame is not read properly, break the loop
        if not ret:
            break
        
        # Detect object
        centers = detect(frame, debugMode)
        
        # If centroids are detected, draw circles on the frame
        if len(centers) > 0:
            for center in centers:
                x, y = center.ravel()
                cv2.circle(frame, (int(x), int(y)), 10, (0, 191, 255), 2)
        
        cv2.imshow('image', frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        
        cv2.waitKey(HiSpeed - ControlSpeedVar + 1)
    
    # Release video capture object and close windows
    VideoCap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
